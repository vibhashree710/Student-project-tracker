# Vibhashree S — Student Project Tracker

Upload `index.html` to a GitHub repository and import it into Vercel to publish.
